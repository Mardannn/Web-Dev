export interface Shipping {
  type: string,
  price: number
}
